
library config.globals;
import 'package:flutter/material.dart';
import 'package:settings_ui/settings_ui.dart';

import 'myTheme.dart';
myTheme currentTheme= myTheme();
class SettingsPage extends StatefulWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  _SettingsPageState createState() => _SettingsPageState();
}
bool isSwitched=false;
class _SettingsPageState extends State<SettingsPage> {
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text('Settings'),
          backgroundColor: Colors.pink,
        ),
        body: SafeArea(
          child: Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/paper.jpg'),
                fit: BoxFit.fill,
              ),
            ),
            padding: const EdgeInsets.all(20),
            child: ListView(
              children: <Widget>[
                SizedBox(
                  height: 20,
                ),
                Expanded(
                  child: Row(
                    children: [
                      Icon(
                        Icons.person,
                        color: Colors.pink,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Divider(
                        height: 20,
                        thickness: 2,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        "Account",
                        style: TextStyle(fontSize: 22),
                      ),
                    ],
                  ),
                ),
                Divider(
                  height: 20,
                  thickness: 2,
                ),
                AccountOption(context, "Change Password"),
                AccountOption(context, "Change Username"),
                AccountOption(context, "Change Profil Photo"),
                SizedBox(
                  height: 20,
                ),
                Expanded(
                  child: Row(
                    children: [
                      Icon(
                        Icons.doorbell_sharp,
                        color: Colors.pink,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Divider(
                        height: 20,
                        thickness: 2,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        "Notifications",
                        style: TextStyle(fontSize: 22),
                      ),
                      SizedBox(
                        width: 150,
                      ),
                      Switch(
                        value: isSwitched,
                        onChanged: (value) {
                          setState(() {
                            isSwitched = value;
                            print(isSwitched);
                          });
                        },
                        activeTrackColor: Colors.pinkAccent,
                        activeColor: Colors.pink,
                      ),
                    ],

                  ),
                ),
                Divider(
                  height: 20,
                  thickness: 2,
                ),
                AccountOption(context, "Set Time"),
                AccountOption(context, "Add Reminder"),
  SizedBox(
    height: 30,
  ),

  ElevatedButton.icon(
    icon: Icon(Icons.brightness_high),
    label: Text('Change the Theme'),
    onPressed: () {
setState(() {
  currentTheme.currentTheme();
});
    },
    style: ElevatedButton.styleFrom(
        primary: Colors.pink,
        padding: EdgeInsets.symmetric(horizontal: 50, vertical: 20),
        textStyle: TextStyle(
            fontSize: 20,),
    ),
  ),


              ],
            ),
          ),
        ),
      );

  GestureDetector AccountOption(BuildContext context, String title) {
    return GestureDetector(
      onTap: () {},
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              title,
              style: TextStyle(fontSize: 20, color: Colors.blueGrey),
            ),
            Icon(Icons.arrow_forward_ios)
          ],
        ),
      ),
    );
  }
}
