import 'package:flutter/material.dart';
import 'package:meditation_app/EntryPage.dart';
import 'package:meditation_app/operations.dart';
import 'package:meditation_app/entry.dart';
import 'package:meditation_app/sideBar.dart';
import 'package:provider/provider.dart';

class Journal extends StatefulWidget {
  const Journal({Key? key}) : super(key: key);

  @override
  _JournalState createState() => _JournalState();
}

class _JournalState extends State<Journal> {
  List <String> items = <String>[];
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: sideBar(),
        appBar: AppBar(
          backgroundColor:
          Color(0xFFE1D7CE),
          elevation: 0.0,
          centerTitle: true,
          title: Text("Journal",
            style: TextStyle(
              fontFamily: 'DancingScript',
              color: Color(0xFF896C64),
              fontSize: 40,
            ),),
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/images/journal2.jpg'),
              fit: BoxFit.fill,
            ),
          ),
          child: Consumer<operations>(
            builder: (context, operations data,child){
              return ListView.builder(
                  itemCount: data.getEntry.length,
                  itemBuilder: (context,index){
                    return NoteCard(data.getEntry[index]);
                  }
              );
            },
          ),
        ),


        floatingActionButton: FloatingActionButton(
          backgroundColor: Colors.white,
          child: Icon(Icons.add, color: Color(0xFF896C64),size:35),
          onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=> EntryPage()));
          },
        ),
      ),
    );
  }
}
class NoteCard extends StatelessWidget {
  final entry e;
  NoteCard(this.e);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(15),
      padding: EdgeInsets.all(15),
      height:90,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(e.title,style: TextStyle(
            fontSize: 20,
            color: Color(0xFF896C64),
            fontWeight: FontWeight.bold,
          ),),
          Text(e.text),
        ],
      ),
    );
  }
}