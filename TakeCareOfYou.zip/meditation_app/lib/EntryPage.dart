import'package:flutter/material.dart';
import 'package:meditation_app/Journal.dart';
import 'package:provider/provider.dart';
import 'package:meditation_app/operations.dart';
class EntryPage extends StatefulWidget {

  const EntryPage({Key? key}) : super(key: key);

  @override
  State<EntryPage> createState() => _EntryPageState();
}

class _EntryPageState extends State<EntryPage> {
  String titleText = " ";
  String entryText = " ";
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: Color(0xFFE1D7CE),
      appBar: AppBar(
        elevation:0,
        backgroundColor: Colors.transparent,
      ),
      body: Padding(
        padding: EdgeInsets.all(15.0),
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: 'Enter Title',
                hintStyle: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
              onChanged: (value){
                titleText = value;
              },
            ),
            Expanded(child: TextField(
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: 'Enter Text (Tap on mic for speech to text)',
                hintStyle: TextStyle(
                  fontWeight: FontWeight.normal,
                  fontSize: 18,
                ),
              ),
              style: TextStyle(
                fontWeight: FontWeight.normal,
                fontSize: 18,
              ),
              onChanged: (value){
                entryText = value;
              },
            ),
            ),
            FlatButton(
                onPressed: (){
                  Provider.of<operations>(context, listen: false).addEntry(titleText, entryText);
                  Navigator.pop(context);
                },

                color: Colors.white,
                child: Text('Add', style: TextStyle(
                  color: Color(0xFF896C64),
                ),)
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.white,
        child: Icon(Icons.mic, color:Color(0xFF896C64),size:35),
        onPressed: (){

        },
      ),


    );
  }
}