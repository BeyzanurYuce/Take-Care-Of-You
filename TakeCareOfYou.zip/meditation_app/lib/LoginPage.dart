import 'package:flutter/material.dart';
import 'package:meditation_app/HomePage.dart';
import 'package:meditation_app/SignUp.dart';
import 'dart:async';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

var email;
var password;

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/background.jpg'),
            fit: BoxFit.fill,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  flex: 7,
                  child: Container(
                    width: 200,
                    height: 200,
                    child: Image(
                        image: AssetImage('assets/images/blue hair girl.png')),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Expanded(
                  flex: 4,
                  child: Text(
                    'Take Care Of You',
                    style: TextStyle(fontSize: 30, color: Colors.cyan),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Padding(
                    padding: const EdgeInsets.only(right: 20, left: 20),
                    child: TextFormField(
                      decoration: InputDecoration(
                        prefixIcon: Icon(Icons.email),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.teal),
                        ),
                        labelText: "Your Email",
                        labelStyle: TextStyle(
                          fontFamily: 'Roboto',
                        ),
                        border: OutlineInputBorder(),
                      ),
                      onSaved: (value) {
                        email = value;
                      },
                    ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Expanded(
                  flex: 3,
                  child: Padding(
                    padding: const EdgeInsets.only(right: 20, left: 20),
                    child: TextFormField(
                      obscureText: true,
                      decoration: InputDecoration(
                        prefixIcon: Icon(Icons.lock),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.teal),
                        ),
                        labelText: "Your Password",
                        labelStyle: TextStyle(
                          fontFamily: 'Roboto',
                        ),
                        border: OutlineInputBorder(),
                      ),
                      onSaved: (value) {
                        password = value;
                      },
                    ),
                  ),
                ),
                SizedBox(
                  height: 50,
                  width: 50,
                ),
                FlatButton(
                  onPressed: () {
                    setState(() {
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>Home()));
                    });
                  },
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(50.0),
                  ),
                  color: Color(0xFFDEA671),
                  padding: EdgeInsets.fromLTRB(70, 10, 70, 10),
                  child: Text('Sign In ',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 21,
                      )),
                ),
                SizedBox(height: 50),
                FlatButton(
                  onPressed: () {
                    setState(() {
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>SignUp()));
                    });
                  },
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(50.0),
                  ),
                  color: Color(0xFFFF6F00),
                  padding: EdgeInsets.fromLTRB(70, 10, 70, 10),
                  child: Text('Sign Up!',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                      )),
                ),
                SizedBox(height: 50),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {

    super.initState();
    Timer(Duration(seconds: 6), () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> LoginPage())));
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomRight, colors: [
            Color(0xffe9cec4),
            Color(0xffcd6a1b)]),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Column(
              children: [

                Image.asset('assets/images/blue hair girl.png',
                  height: 450.0,
                  width: 300.0, ),
                Text("Welcome",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 30.0),
                ),

              ],
            ),

            CircularProgressIndicator()
          ],
        ),
      ),
    );
  }
}