class entry{
  String title;
  String text;
  entry(this.title, this.text);
}