import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:meditation_app/sideBar.dart';
import 'package:meditation_app/track_categories.dart';

import 'Journal.dart';


class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: sideBar(),

      appBar: AppBar(
        centerTitle: true,
        title: Text('Take Care Of You '),
        backgroundColor: Colors.cyan,

      ),
      body:Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/background.jpg'),
            fit: BoxFit.fill,
          ),
        ),
        child: Center(
          child: Column(

              children:<Widget>[
                Expanded(
                  flex: 2,
                  child: Image(
                      width: 100.0,
                      height: 100.0,
                      image: AssetImage('assets/images/cute cartoon meditation_6223223.png')),
                ),
                Text("Welcome User ! Let's get started. ",style: TextStyle(color: Colors.indigo,fontSize: 24),),

                SizedBox(
                  width: 50.0,
                  height:50.0,
                ),


                Expanded(
                  flex: 3,
                  child: SizedBox(
                    width:500.0,
                    height: 200.0,

                    child: TextButton.icon(
                      style: ButtonStyle(
                          backgroundColor:
                          MaterialStateProperty.all(Colors.cyan),
                          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(18.0),
                              )
                          )
                      ),

                      onPressed: () {
                        Navigator.push(context,MaterialPageRoute(builder:(context)=>TrackCategories()));
                      },
                      icon: Image.asset('assets/images/space.jpg'),
                      label: Text(
                        'Start medtation',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.indigo,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 40.0,
                  width: 50.0,
                ),
                Expanded(
                  flex: 3,
                  child: SizedBox(
                    width:500.0,
                    height: 200.0,

                    child: TextButton.icon(

                      style: ButtonStyle(
                          backgroundColor:
                          MaterialStateProperty.all(Colors.cyan),
                          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(18.0),
                              )
                          )
                      ),
                      onPressed: () {
                        Navigator.push(context,MaterialPageRoute(builder:(context)=>Journal()));
                      },
                      icon: Image.asset('assets/images/journaling.jpeg'),

                      label: Text(
                        'Start journaling',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.indigo,
                          fontWeight: FontWeight.bold,
                        ),

                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 20.0,
                  width: 50.0,
                ),
              ]

          ),
        ),
      ),
    );
  }
}