import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:syncfusion_flutter_charts/sparkcharts.dart';
import 'dart:async';

class MeditationTrack extends StatefulWidget {
  const MeditationTrack({Key? key}) : super(key: key);
  @override
  State<MeditationTrack> createState() => _MeditationTrackState();
}

class _MeditationTrackState extends State<MeditationTrack> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        //To get the focus out of the search bar when tapped on AppBar
/*         flexibleSpace: GestureDetector(
          onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
        ), */
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          'Track_Name',
          style: TextStyle(color: Colors.black, fontStyle: FontStyle.italic),
        ),
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: LayoutBuilder(builder: (context, Constraints) {
          if (Constraints.maxWidth < 600) {
            return Column(
              children: [
                Expanded(
                  flex: 4,
                  child: buildCircularTrackProgress(),
                ),
                Expanded(
                  flex: 2,
                  child: buildMantra(),
                ),
                Expanded(
                  flex: 2,
                  child: buildHeartrateMonitor(),
                )
              ],
            );
          } else {
            return Row(
              children: [
                Expanded(
                  flex: 1,
                  child: buildCircularTrackProgress(),
                ),
                Expanded(
                    flex: 1,
                    child: Column(
                      children: [
                        Spacer(
                          flex: 1,
                        ),
                        Expanded(
                          flex: 2,
                          child: buildHeartrateMonitor(),
                        ),
                        Expanded(
                          flex: 2,
                          child: buildMantra(),
                        ),
                      ],
                    ))
              ],
            );
          }
        }),
      ),
    );
  }

  Padding buildHeartrateMonitor() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15.0),
            border: Border.all(
              color: Colors.red.shade100,
              width: 3,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: SfSparkLineChart(
              color: Colors.grey,
              lastPointColor: Colors.red,
              axisLineColor: Colors.transparent,
              data: <double>[
                120,
                122,
                123,
                110,
                112,
                123,
                110,
                100,
                95,
                94,
                93,
                95,
                95,
                95,
                80,
                95,
                85,
                85,
                84,
                85,
              ],
            ),
          )),
    );
  }

  Column buildMantra() {
    return Column(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
      Text(
        'Loka samasta sukhino bhavantu',
        style: TextStyle(fontSize: 16, letterSpacing: 2),
      ),
      Spacer(
        flex: 1,
      ),
      Text(
        'May all beings be happy and free',
        style: TextStyle(fontSize: 10),
      ),
      Spacer(
        flex: 3,
      )
    ]);
  }

  CircularPercentIndicator buildCircularTrackProgress() {
    return CircularPercentIndicator(
      circularStrokeCap: CircularStrokeCap.butt,
      animation: true,
      animationDuration: 12000,
      radius: 150.0,
      lineWidth: 6.0,
      percent: 1,
      center: IconButton(
        iconSize: 90,
        icon: CircleAvatar(
          radius: 50.0,
          backgroundImage: AssetImage('assets/images/meditation_track_img.png'),
          backgroundColor: Colors.transparent,
        ),
        onPressed: () {},
      ),
      backgroundColor: Colors.red[50],
      progressColor: Colors.red[300],
    );
  }
}