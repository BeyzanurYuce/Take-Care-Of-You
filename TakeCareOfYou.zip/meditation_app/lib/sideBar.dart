import 'package:flutter/material.dart';
import 'package:meditation_app/track_categories.dart';
import 'settings.dart';

import 'Contact.dart';
import 'Journal.dart';
import 'LoginPage.dart';

class sideBar extends StatelessWidget {
  const sideBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: [
          UserAccountsDrawerHeader(
            accountName: Text('User'),
            accountEmail: Text('someone@gmail.com'),
            currentAccountPicture: CircleAvatar(
                child: ClipOval(
                  child: Image.network(
                      'https://www.publicdomainpictures.net/pictures/270000/velka/sunset-woman-silhouette-sunset.jpg',
                      height: 90,
                      width: 90,
                      fit: BoxFit.cover),
                )),
            decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage(
                  'https://media.istockphoto.com/photos/beautiful-sunset-colors-teal-and-orange-picture-id924837306?k=20&m=924837306&s=170667a&w=0&h=EvMjoV3hmLwbZiXF-ywKrV0kW7QfNI7uDhPGmc2PoC0=',
                ),
                fit: BoxFit.cover,
              ),
              color: Color(0xFFFAC191),
            ),
          ),
          ListTile(
            leading:
            Icon(Icons.auto_awesome, size: 30, color: Color(0xFFDE9D8D)),
            title: Text('Meditate'),
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>TrackCategories()));
            },
          ),
          ListTile(
            //tileColor:Color(0xFFE4C4D0),
            leading:
            Icon(Icons.auto_stories, size: 30, color: Color(0xFFDE9D8D)),
            title: Text('Journal'),
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>Journal()));
            },
          ),
          ListTile(
            leading: Icon(Icons.assignment, size: 30, color: Color(0xFFDE9D8D)),
            title: Text('Previous Actions'),
            onTap: () => null,
          ),
          ListTile(
            leading: Icon(Icons.settings, size: 30, color: Color(0xFFDE9D8D)),
            title: Text('Settings'),
            onTap: () {Navigator.push(context, MaterialPageRoute(builder: (context)=>SettingsPage()));},
          ),
          SizedBox(
            height: 160,
          ),
          ListTile(
            leading: Icon(Icons.mail, size: 30, color: Color(0xFFDE9D8D)),
            title: Text('Contact Us'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context)=>Contact()));
            },
          ),
          ListTile(
            leading: Icon(Icons.logout, size: 30, color: Color(0xFFDE9D8D)),
            title: Text('Sign out'),
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginPage()));
            },
          ),
        ],
      ),
    );
  }
}