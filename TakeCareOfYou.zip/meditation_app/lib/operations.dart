import 'package:flutter/material.dart';
import 'package:meditation_app/entry.dart';

class operations extends ChangeNotifier {
  List <entry> entries = <entry>[];

  List<entry> get getEntry {
    return entries;
  }
  operations(){
    addEntry('Title 1','Text 1');
  }
  void addEntry(String title, String description){
    entry e = entry(title, description);
    entries.add(e);
    notifyListeners();
  }
  void removeEntry(String title, String description){
    entry e = entry(title, description);
    entries.remove(e);
    notifyListeners();
  }
}